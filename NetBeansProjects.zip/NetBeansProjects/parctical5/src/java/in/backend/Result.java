package in.backend;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
@WebServlet("/result")
public class Result extends HttpServlet {
 protected void doPost(HttpServletRequest request, HttpServletResponse
response) throws ServletException, IOException {
 HttpSession session = request.getSession();
 String name = (String) session.getAttribute("name");
 String id = (String) session.getAttribute("id");
 String department = (String) session.getAttribute("department");
 int totalMarks = 0;
 boolean isFail = false;
 for (int i = 1; i <= 6; i++) {
 int marks = Integer.parseInt(request.getParameter("subject" + i));
 if (marks < 35) {
 isFail = true;
 }
 totalMarks += marks;
 }
 String result = isFail ? "Fail" : "Pass";
 response.setContentType("text/html");
 PrintWriter out = response.getWriter();
 out.println("<html><body>");
 out.println("<h1>Result for " + name + "</h1>");
 out.println("<p>ID: " + id + "</p>");
 out.println("<p>Department: " + department + "</p>");
 out.println("<p>Total Marks: " + totalMarks + "</p>");
 out.println("<h2 style='color:" + (isFail ? "red" : "green") + "'>Result: " +
result + "</h2>");
 out.println("</body></html>");
 }
}