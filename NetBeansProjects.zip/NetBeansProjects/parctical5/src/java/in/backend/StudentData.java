package in.backend;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
@WebServlet("/studentdata")
public class StudentData extends HttpServlet {
 protected void doPost(HttpServletRequest request, HttpServletResponse
response) throws ServletException, IOException {
 String name = request.getParameter("name");
 String id = request.getParameter("id");
 String department = request.getParameter("department");
 HttpSession session = request.getSession();
 session.setAttribute("name", name);
 session.setAttribute("id", id);
 session.setAttribute("department", department);
 response.setContentType("text/html");
 PrintWriter out = response.getWriter();
 out.println("<html><body>");
 out.println("<h1>Welcome, " + name + "!</h1>");
 out.println("<form action='marksentry' method='post'>");
 out.println("<button type='submit'>Next</button>");
 out.println("</form>");
 out.println("</body></html>");
 }
}
