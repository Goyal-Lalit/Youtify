package in.ga.backend;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet(name = "Redirect", urlPatterns = {"/Redirect"})
public class Redirect extends HttpServlet {
 protected void doPost(HttpServletRequest request,
HttpServletResponse response)
 throws ServletException, IOException {

 String url = request.getParameter("url");
 if (!url.startsWith("http://") && !url.startsWith("https://")) {
 url = "http://" + url;
 }
 response.sendRedirect(url);
 }
}